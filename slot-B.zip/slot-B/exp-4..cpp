#include <stdio.h>
int main(void) {
    int n, bt[100], p[100], wt[100], tat[100], i,j,t;
    float sw=0,st=0;
    printf("Number of processes (1-100): ");
    if(scanf("%d",&n)!=1||n<1||n>100)return 1;
    for(i=0;i<n;i++){p[i]=i+1;printf("Burst time P%d: ",p[i]);if(scanf("%d",&bt[i])!=1||bt[i]<0)return 1;}
    for(i=0;i<n-1;i++)for(j=i+1;j<n;j++)if(bt[j]<bt[i]){t=bt[i];bt[i]=bt[j];bt[j]=t;t=p[i];p[i]=p[j];p[j]=t;}
    wt[0]=0;
    for(i=1;i<n;i++)wt[i]=wt[i-1]+bt[i-1];
    printf("Process\tBT\tWT\tTAT\n");
    for(i=0;i<n;i++){tat[i]=wt[i]+bt[i];sw+=wt[i];st+=tat[i];printf("P%d\t%d\t%d\t%d\n",p[i],bt[i],wt[i],tat[i]);}
    printf("Average WT=%.2f\nAverage TAT=%.2f\n",sw/n,st/n);return 0;
}


