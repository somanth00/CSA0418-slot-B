
#include <stdio.h>
#include <string.h>

int main(void)
{
    char message[100] = "Hello using message queue";
    char received[100];

    /* Simulate sending a message */
    strcpy(received, message);

    /* Display the received message */
    printf("Received: %s\n", received);

    return 0;
}

