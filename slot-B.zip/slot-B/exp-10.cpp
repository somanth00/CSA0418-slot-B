#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>
int main(void) {
    int id=shmget(IPC_PRIVATE,1024,IPC_CREAT|0600);
    char *p;
    if(id==-1){perror("shmget");return 1;}
    p=(char *)shmat(id,NULL,0);
    if(p==(char *)-1){perror("shmat");shmctl(id,IPC_RMID,NULL);return 1;}
    strcpy(p,"Hello from shared memory");
    printf("Data stored in shared memory: %s\n",p);
    if(shmdt(p)==-1)perror("shmdt");
    if(shmctl(id,IPC_RMID,NULL)==-1)perror("shmctl");
    return 0;
}

