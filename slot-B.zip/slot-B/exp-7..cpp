#include <stdio.h>
int main(void) {
    int n,at[50],bt[50],done[50]={0},ct[50]={0},i,time=0,finished=0,idx;
    float sw=0,st=0;
    printf("Number of processes (1-50): ");if(scanf("%d",&n)!=1||n<1||n>50)return 1;
    for(i=0;i<n;i++){printf("P%d arrival burst: ",i+1);if(scanf("%d%d",&at[i],&bt[i])!=2||at[i]<0||bt[i]<1)return 1;}
    while(finished<n){idx=-1;for(i=0;i<n;i++)if(!done[i]&&at[i]<=time&&(idx==-1||bt[i]<bt[idx]))idx=i;
        if(idx==-1){time++;continue;}time+=bt[idx];ct[idx]=time;done[idx]=1;finished++;}
    printf("Process\tAT\tBT\tWT\tTAT\n");
    for(i=0;i<n;i++){int tat=ct[i]-at[i],wt=tat-bt[i];sw+=wt;st+=tat;printf("P%d\t%d\t%d\t%d\t%d\n",i+1,at[i],bt[i],wt,tat);}
    printf("Average WT=%.2f\nAverage TAT=%.2f\n",sw/n,st/n);return 0;
}

