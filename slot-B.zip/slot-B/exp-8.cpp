#include <stdio.h>
int main(void) {
    int n,at[50],bt[50],rem[50],ct[50]={0},q,i,time=0,done=0,progress;
    float sw=0,st=0;
    printf("Number of processes (1-50): ");if(scanf("%d",&n)!=1||n<1||n>50)return 1;
    for(i=0;i<n;i++){printf("P%d arrival burst: ",i+1);if(scanf("%d%d",&at[i],&bt[i])!=2||at[i]<0||bt[i]<1)return 1;rem[i]=bt[i];}
    printf("Time quantum: ");if(scanf("%d",&q)!=1||q<1)return 1;
    while(done<n){progress=0;for(i=0;i<n;i++)if(rem[i]>0&&at[i]<=time){progress=1;if(rem[i]<q){time+=rem[i];rem[i]=0;}else{time+=q;rem[i]-=q;}if(rem[i]==0){ct[i]=time;done++;}}
        if(!progress)time++;}
    printf("Process\tAT\tBT\tWT\tTAT\n");
    for(i=0;i<n;i++){int tat=ct[i]-at[i],wt=tat-bt[i];sw+=wt;st+=tat;printf("P%d\t%d\t%d\t%d\t%d\n",i+1,at[i],bt[i],wt,tat);}
    printf("Average WT=%.2f\nAverage TAT=%.2f\n",sw/n,st/n);return 0;
}

