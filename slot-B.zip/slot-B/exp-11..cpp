#include <stdio.h>
#include <pthread.h>
void *worker(void *arg) {
    int id=*(int *)arg;
    printf("Thread %d is running\n",id);
    return NULL;
}
int main(void) {
    pthread_t t[2];int id[2]={1,2},i;
    for(i=0;i<2;i++)if(pthread_create(&t[i],NULL,worker,&id[i])!=0){perror("pthread_create");return 1;}
    for(i=0;i<2;i++)pthread_join(t[i],NULL);
    puts("All threads completed");return 0;
}


