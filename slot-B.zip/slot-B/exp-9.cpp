
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
    FILE *fp;
    char data[1024];

    strcpy(data, "Hello from shared memory");

    fp = fopen("shared_memory.txt", "w");

    if (fp == NULL)
    {
        perror("Error opening file");
        return 1;
    }

    fprintf(fp, "%s", data);
    fclose(fp);

    printf("Data stored in shared memory: %s\n", data);

    fp = fopen("shared_memory.txt", "r");

    if (fp == NULL)
    {
        perror("Error reading file");
        return 1;
    }

    fgets(data, sizeof(data), fp);
    fclose(fp);

    printf("Data read from shared memory: %s\n", data);

    remove("shared_memory.txt");

    return 0;
}

