#include <stdio.h>
int main(void) {
    int n, bt[100], wt[100], tat[100], i;
    float sw=0, st=0;
    printf("Number of processes (1-100): ");
    if (scanf("%d",&n)!=1 || n<1 || n>100) return 1;
    for(i=0;i<n;i++){ printf("Burst time P%d: ",i+1); if(scanf("%d",&bt[i])!=1||bt[i]<0)return 1; }
    wt[0]=0;
    for(i=1;i<n;i++) wt[i]=wt[i-1]+bt[i-1];
    printf("Process\tBT\tWT\tTAT\n");
    for(i=0;i<n;i++){ tat[i]=wt[i]+bt[i]; sw+=wt[i]; st+=tat[i]; printf("P%d\t%d\t%d\t%d\n",i+1,bt[i],wt[i],tat[i]); }
    printf("Average WT=%.2f\nAverage TAT=%.2f\n",sw/n,st/n);
    return 0;
}

