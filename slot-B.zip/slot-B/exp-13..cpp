#include <stdio.h>
int main(void) {
    int n=5,i;
    puts("Dining Philosophers simulation (one philosopher eats at a time):");
    for(i=0;i<n;i++)printf("Philosopher %d thinks.\n",i+1);
    for(i=0;i<n;i++)printf("Philosopher %d picks up forks, eats, and releases forks.\n",i+1);
    puts("Simulation completed without deadlock.");return 0;
}

